package com.ensa.smarthome

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val ESP_IP = "192.168.66.100"
    private val handler = Handler(Looper.getMainLooper())
    private var isRefreshing = false

    private lateinit var lampCard: LinearLayout
    private lateinit var sensorCard: LinearLayout
    private lateinit var lampStatus: TextView
    private lateinit var tempValue: TextView
    private lateinit var humValue: TextView
    private lateinit var btnOn: Button
    private lateinit var btnOff: Button
    private lateinit var segmentedControl: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lampCard        = findViewById(R.id.lampCard)
        sensorCard      = findViewById(R.id.sensorCard)
        lampStatus      = findViewById(R.id.lampStatus)
        tempValue       = findViewById(R.id.tempValue)
        humValue        = findViewById(R.id.humValue)
        btnOn           = findViewById(R.id.btnOn)
        btnOff          = findViewById(R.id.btnOff)
        segmentedControl = findViewById(R.id.segmentedControl)

        // Segmented Control
        segmentedControl.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.btnTabLamp -> {
                    lampCard.visibility   = View.VISIBLE
                    sensorCard.visibility = View.GONE
                    stopRefresh()
                }
                R.id.btnTabSensor -> {
                    lampCard.visibility   = View.GONE
                    sensorCard.visibility = View.VISIBLE
                    startRefresh()
                }
            }
        }

        // Boutons lampe
        btnOn.setOnClickListener  { sendRequest("ledon")  }
        btnOff.setOnClickListener { sendRequest("ledoff") }
    }

    private fun sendRequest(endpoint: String) {
        Thread {
            try {
                val url = URL("http://$ESP_IP/$endpoint")
                val response = url.readText()
                runOnUiThread {
                    if (endpoint == "ledon")  lampStatus.text = "Lampe : ALLUMÉE 💡"
                    if (endpoint == "ledoff") lampStatus.text = "Lampe : ÉTEINTE"
                    if (endpoint == "read")   parseSensorData(response)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (endpoint == "read") {
                        tempValue.text = "Err"
                        humValue.text  = "Err"
                    }
                }
            }
        }.start()
    }

    private fun parseSensorData(data: String) {
        // Format attendu : "T:24.5 H:60.2"
        try {
            val parts = data.trim().split(" ")
            val t = parts[0].replace("T:", "")
            val h = parts[1].replace("H:", "")
            tempValue.text = "${t}°C"
            humValue.text  = "${h}%"
        } catch (e: Exception) {
            tempValue.text = "--°C"
            humValue.text  = "--%"
        }
    }

    private val refreshRunnable = object : Runnable {
        override fun run() {
            sendRequest("read")
            handler.postDelayed(this, 3000)
        }
    }

    private fun startRefresh() {
        if (!isRefreshing) {
            isRefreshing = true
            handler.post(refreshRunnable)
        }
    }

    private fun stopRefresh() {
        isRefreshing = false
        handler.removeCallbacks(refreshRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRefresh()
    }
}