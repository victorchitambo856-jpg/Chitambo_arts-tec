Copyright © 2026 Victor Chitambo (Code APOGEE: 23013004). All rights reserved.

passwords:
       
  Username: admin
Password: cisco123
Enable password:victor



#THE PROJECT SIMULATION IN PACKET TRACER  IS SIGNED(USER PROFILE) FOR AUTHORSHIP PURPOSES.
